// Aggiunge il permesso per le notifiche (Android 13+) se manca.
const fs = require('fs');
const p = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(p, 'utf8');
const perms = ['android.permission.POST_NOTIFICATIONS', 'android.permission.INTERNET'];
for (const perm of perms) {
  if (!x.includes(perm)) x = x.replace('</manifest>', `    <uses-permission android:name="${perm}" />\n</manifest>`);
}
fs.writeFileSync(p, x);
console.log('Manifest aggiornato');
