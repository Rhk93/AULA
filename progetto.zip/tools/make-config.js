// Legge firebase-config.txt (quello che hai incollato da Firebase) e crea www/firebase-config.js
const fs = require('fs'); const vm = require('vm');
const src = fs.readFileSync('firebase-config.txt', 'utf8');
let start = src.indexOf('{', Math.max(0, src.indexOf('firebaseConfig')));
if (start < 0) { console.error('ERRORE: in firebase-config.txt non trovo la configurazione { ... } di Firebase.'); process.exit(1); }
let depth = 0, end = -1;
for (let i = start; i < src.length; i++) {
  if (src[i] === '{') depth++;
  else if (src[i] === '}') { depth--; if (depth === 0) { end = i; break; } }
}
if (end < 0) { console.error('ERRORE: la configurazione in firebase-config.txt è incompleta (manca una "}").'); process.exit(1); }
const literal = src.slice(start, end + 1);
let cfg;
try { cfg = vm.runInNewContext('(' + literal + ')'); }
catch (e) { console.error('ERRORE: non riesco a leggere la configurazione incollata: ' + e.message); process.exit(1); }
if (!cfg.apiKey || String(cfg.apiKey).includes('INCOLLA') || !cfg.projectId) {
  console.error('ERRORE: firebase-config.txt contiene ancora l\'esempio. Incolla la configurazione del TUO progetto Firebase.');
  process.exit(1);
}
fs.writeFileSync('www/firebase-config.js', 'window.FIREBASE_CONFIG = ' + JSON.stringify(cfg, null, 2) + ';\n');
console.log('Configurazione Firebase pronta per il progetto: ' + cfg.projectId);
