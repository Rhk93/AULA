/* Aula Digitale – app collegata al TUO progetto Firebase.
   I dati (lezioni, compiti, esercitazioni, voti) restano nel tuo account Google. */
const FB = 'https://www.gstatic.com/firebasejs/10.14.1/';

/* ================= utilità di interfaccia ================= */
const ICON = {
  video:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="2" y="6" width="14" height="12" rx="2"/><path d="m16 10 6-3v10l-6-3z"/></svg>',
  foto:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/></svg>',
  audio:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
  documento:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h6"/></svg>',
  altro:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg>'
};
const STAR = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="m12 2.8 2.8 6 6.5.7-4.9 4.4 1.4 6.4L12 17l-5.8 3.3 1.4-6.4-4.9-4.4 6.5-.7z"/></svg>';
const KINDS = [['video','Video'],['foto','Foto'],['audio','Audio'],['documento','Documento'],['altro','Altro link']];

const $main = document.getElementById('main');
const h = (tag, attrs={}, ...kids) => {
  const el = document.createElement(tag);
  for (const [k,v] of Object.entries(attrs||{})) {
    if (v==null || v===false) continue;
    if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k==='html') el.innerHTML = v;
    else el.setAttribute(k, v===true?'':v);
  }
  for (const c of kids.flat()) if (c!=null && c!==false) el.append(c.nodeType?c:document.createTextNode(String(c)));
  return el;
};
const newId = () => Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const safeUrl = u => /^https?:\/\//i.test((u||'').trim()) ? u.trim() : null;
const host = u => { try { return new URL(u).hostname.replace(/^www\./,''); } catch { return ''; } };
const ls = { get(k,d){ try{ const v=localStorage.getItem(k); return v==null?d:JSON.parse(v); }catch{ return d; } },
             set(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch{} } };

function toast(msg){
  const t = h('div',{class:'toast',role:'status'},msg); document.body.append(t);
  setTimeout(()=>t.remove(), 3500);
}
function errMsg(e){
  const c = (e && e.code) || '';
  if (c.includes('permission-denied')) return 'Non hai il permesso per questa operazione.';
  if (c.includes('unavailable') || c.includes('network')) return 'Sei offline o la connessione è debole. Riprova.';
  if (c.includes('resource-exhausted') || c.includes('quota')) return 'Limite gratuito di Firebase raggiunto per oggi. Riprova domani.';
  return 'Operazione non riuscita. Riprova.';
}
const fail = e => { console.error(e); toast(errMsg(e)); };

/* finestre a scorrimento (al posto di alert/confirm) */
function sheet(title, body, actions){
  const bg = h('div',{class:'sheet-bg',onclick:e=>{ if(e.target===bg) bg.remove(); }});
  const box = h('div',{class:'sheet',role:'dialog','aria-modal':'true','aria-label':title}, h('h2',{},title), body, actions(()=>bg.remove()));
  bg.append(box); document.body.append(bg);
  return bg;
}
function form(title, fields, submitLabel, onSubmit){
  const els = {};
  const err = h('p',{class:'err',hidden:true});
  const body = h('div',{style:'display:flex;flex-direction:column;gap:12px'},
    fields.map(f=>{
      let inp;
      if (f.type==='textarea') inp = h('textarea',{id:'f-'+f.id});
      else if (f.type==='select') inp = h('select',{id:'f-'+f.id}, f.options.map(([v,l])=>h('option',{value:v},l)));
      else inp = h('input',{id:'f-'+f.id,type:f.type||'text',inputmode:f.inputmode,placeholder:f.placeholder||'',accept:f.accept,autocomplete:f.autocomplete});
      if (f.value!=null && f.type!=='file') inp.value = f.value;
      els[f.id]=inp;
      return h('label',{class:'f',for:'f-'+f.id}, f.label, inp, f.help?h('span',{class:'hint',style:'font-weight:400'},f.help):null);
    }), err);
  els._err = err;
  sheet(title, body, close => h('div',{class:'row',style:'justify-content:flex-end'},
    h('button',{class:'btn ghost',type:'button',onclick:close},'Annulla'),
    h('button',{class:'btn primary',type:'button',onclick:async e=>{
      const btn=e.currentTarget; err.hidden=true; btn.disabled=true;
      try { const msg = await onSubmit(els); if (msg) { err.textContent=msg; err.hidden=false; } else close(); }
      catch(x){ console.error(x); err.textContent=errMsg(x); err.hidden=false; }
      btn.disabled=false;
    }}, submitLabel)));
}
function confirmBox(title, text, okLabel, onOk){
  sheet(title, h('p',{style:'margin:0'},text), close => h('div',{class:'row',style:'justify-content:flex-end'},
    h('button',{class:'btn ghost',type:'button',onclick:close},'Annulla'),
    h('button',{class:'btn primary',type:'button',style:'background:var(--danger);color:#fff',onclick:async()=>{ close(); try{ await onOk(); }catch(e){ fail(e); } }}, okLabel)));
}

/* date */
function todayStr(){ const d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }
function parseDue(due){ if(!due) return null; const [y,m,d]=due.split('-').map(Number); return new Date(y,m-1,d); }
function daysTo(due){ const a=parseDue(due); if(!a) return null; const t=new Date(); t.setHours(0,0,0,0); return Math.round((a-t)/86400000); }
function fmtDate(due){ const a=parseDue(due); return a ? a.toLocaleDateString('it-IT',{weekday:'short',day:'numeric',month:'long'}) : ''; }
function dueChip(due){
  const n = daysTo(due); if (n==null) return null;
  if (n<0) return h('span',{class:'pill late'},'Scaduto');
  if (n===0) return h('span',{class:'pill warn'},'Scade oggi');
  if (n===1) return h('span',{class:'pill warn'},'Scade domani');
  return h('span',{class:'pill'},'Tra '+n+' giorni');
}

/* ================= stato ================= */
const S = {
  fb:null, user:null, uid:null, teacherUid:undefined, member:undefined, owner:false,
  lessons:[], tasks:[], subs:[], ratings:[], members:[], theme:null, bgData:'', app:{storage:false}, secret:null,
  state:{seen:0, done:{}}, loaded:{}, tab:'lezioni', lesson:null, started:false, unsubs:[], customizing:false
};

/* ================= avvio Firebase ================= */
let F = {};
async function boot(){
  const cfg = window.FIREBASE_CONFIG;
  if (!cfg || !cfg.apiKey || String(cfg.apiKey).includes('INCOLLA')) return renderNoConfig();
  try {
    const [app, auth, fs] = await Promise.all([
      import(FB+'firebase-app.js'), import(FB+'firebase-auth.js'), import(FB+'firebase-firestore.js')]);
    F = {...app, ...auth, ...fs};
  } catch (e) { return renderOffline(); }
  const app = F.initializeApp(cfg);
  let auth;
  try { auth = F.initializeAuth(app, {persistence:[F.indexedDBLocalPersistence, F.browserLocalPersistence]}); }
  catch { auth = F.getAuth(app); }
  const db = F.getFirestore(app);
  S.fb = {app, auth, db};
  F.onAuthStateChanged(auth, user => {
    stopAll();
    S.user=user; S.uid=user?user.uid:null; S.teacherUid=undefined; S.member=undefined; S.owner=false;
    if (!user) return renderLogin();
    watchRole();
  });
}
const D = p => F.doc(S.fb.db, p);
const C = p => F.collection(S.fb.db, p);
function stopAll(){ S.unsubs.forEach(u=>{ try{u();}catch{} }); S.unsubs=[]; S.started=false; S.loaded={};
  S.lessons=[];S.tasks=[];S.subs=[];S.ratings=[];S.members=[];S.secret=null; }
function sub(ref, next, name){
  const u = F.onSnapshot(ref, next, e=>{ console.error(name, e); if (name) { S.loaded[name]=true; render(); } });
  S.unsubs.push(u); return u;
}

function watchRole(){
  renderLoading('Controllo il tuo accesso alla classe…');
  sub(D('config/teacher'), d=>{ S.teacherUid = d.exists() ? d.data().uid : null; decide(); });
  S.unsubs.push(F.onSnapshot(D('members/'+S.uid), d=>{ S.member = d.exists() ? d.data() : null; decide(); }, ()=>{ S.member=null; decide(); }));
}
function decide(){
  if (S.teacherUid===undefined) return;
  S.owner = !!S.teacherUid && S.teacherUid===S.uid;
  if (S.owner || S.member){ if (!S.started) startClass(); else render(); return; }
  if (S.member===undefined) return;
  if (S.started){ stopAll(); S.member=undefined; watchRole(); return; }
  renderJoin();
}

function startClass(){
  S.started = true;
  const lsn = (name, ref, map) => sub(ref, s=>{ map(s); S.loaded[name]=true; render(); onData(name); }, name);
  lsn('lessons', F.query(C('lessons'), F.orderBy('num')), s=>{ S.lessons=s.docs.map(d=>({id:d.id,...d.data()})); });
  lsn('tasks', F.query(C('tasks'), F.orderBy('due')), s=>{ S.tasks=s.docs.map(d=>({id:d.id,...d.data()})); });
  lsn('subs', F.query(C('subs'), F.orderBy('createdAt','desc')), s=>{ S.subs=s.docs.map(d=>({id:d.id,...d.data()})); });
  lsn('ratings', C('ratings'), s=>{ S.ratings=s.docs.map(d=>({id:d.id,...d.data()})); });
  lsn('members', C('members'), s=>{ S.members=s.docs.map(d=>({id:d.id,...d.data()})); });
  sub(D('settings/theme'), d=>{ S.theme = d.exists()?d.data():null; if(!S.customizing) applyTheme(S.theme); });
  sub(D('settings/background'), d=>{ S.bgData = d.exists()?(d.data().data||''):''; if(!S.customizing) applyTheme(S.theme); });
  sub(D('settings/app'), d=>{ S.app = d.exists()?d.data():{storage:false}; render(); });
  sub(D('users/'+S.uid+'/private/state'), d=>{
    if (d.exists()){ const v=d.data(); S.state={...S.state, seen:v.seen||0, done:{...(v.done||{})}}; }
    S.loaded.state=true; render(); onData('state');
  });
  if (S.owner) sub(D('secret/class'), d=>{ S.secret = d.exists()?d.data():null; });
  Notif.init();
  render();
}

/* ================= schermate di accesso ================= */
function shell(on){
  document.getElementById('tabs').hidden = !on;
  document.getElementById('gear').hidden = !on;
  document.getElementById('role').hidden = !on;
  $main.style.paddingBottom = on ? '' : '24px';
}
function renderLoading(text){ shell(false); $main.replaceChildren(h('div',{class:'wrap'}, h('p',{class:'hint'},text))); }
function renderNoConfig(){
  shell(false);
  $main.replaceChildren(h('div',{class:'wrap'}, h('div',{class:'card'},
    h('h2',{},'Manca la configurazione di Firebase'),
    h('p',{style:'margin:0'},'Nel progetto su GitHub crea o modifica il file firebase-config.js incollando la configurazione che Firebase ti mostra in Impostazioni progetto → Le tue app. Poi ricompila l’app.'))));
}
function renderOffline(){
  shell(false);
  $main.replaceChildren(h('div',{class:'wrap'}, h('div',{class:'card'},
    h('h2',{},'Serve la connessione a internet'),
    h('p',{style:'margin:0'},'L’app non riesce a collegarsi. Controlla il Wi‑Fi o i dati mobili e riaprila.'),
    h('button',{class:'btn primary',onclick:()=>location.reload()},'Riprova'))));
}
function renderLogin(mode='login'){
  shell(false); applyTheme(null);
  const err = h('p',{class:'err',hidden:true});
  const email = h('input',{id:'l-email',type:'email',autocomplete:'email',inputmode:'email',placeholder:'nome@email.it'});
  const pass = h('input',{id:'l-pass',type:'password',autocomplete:mode==='login'?'current-password':'new-password',placeholder:'Almeno 6 caratteri'});
  const go = async e => {
    e.preventDefault(); err.hidden=true;
    const em=email.value.trim(), pw=pass.value;
    if (!em || !pw) { err.textContent='Scrivi email e password.'; err.hidden=false; return; }
    try {
      if (mode==='login') await F.signInWithEmailAndPassword(S.fb.auth, em, pw);
      else await F.createUserWithEmailAndPassword(S.fb.auth, em, pw);
    } catch (x) {
      const c = x.code||'';
      err.textContent = c.includes('invalid-credential')||c.includes('wrong-password')||c.includes('user-not-found') ? 'Email o password non corrette.'
        : c.includes('email-already-in-use') ? 'Esiste già un account con questa email: usa «Accedi».'
        : c.includes('weak-password') ? 'La password deve avere almeno 6 caratteri.'
        : c.includes('invalid-email') ? 'L’indirizzo email non è valido.'
        : c.includes('operation-not-allowed') ? 'Nel tuo progetto Firebase non è ancora attivo l’accesso con email e password (Authentication → Metodo di accesso).'
        : c.includes('network') ? 'Sei offline. Controlla la connessione.' : 'Accesso non riuscito. Riprova.';
      err.hidden=false;
    }
  };
  $main.replaceChildren(h('div',{class:'auth'}, h('form',{class:'card',onsubmit:go},
    h('h1',{},'Aula Digitale'),
    h('p',{class:'hint'}, mode==='login' ? 'Accedi con il tuo account della classe.' : 'Crea il tuo account. Dopo ti chiederemo il codice della classe.'),
    h('label',{class:'f',for:'l-email'},'Email',email),
    h('label',{class:'f',for:'l-pass'},'Password',pass), err,
    h('button',{class:'btn primary',type:'submit'}, mode==='login'?'Accedi':'Crea account'),
    h('div',{class:'row',style:'justify-content:space-between'},
      h('button',{class:'linkbtn',type:'button',onclick:()=>renderLogin(mode==='login'?'signup':'login')}, mode==='login'?'Non hai un account? Registrati':'Hai già un account? Accedi'),
      mode==='login' ? h('button',{class:'linkbtn',type:'button',onclick:async()=>{
        const em=email.value.trim(); if(!em){ err.textContent='Scrivi prima la tua email, poi tocca «Password dimenticata».'; err.hidden=false; return; }
        try{ await F.sendPasswordResetEmail(S.fb.auth, em); toast('Ti abbiamo mandato un’email per reimpostare la password.'); }catch{ toast('Invio non riuscito: controlla l’email.'); }
      }},'Password dimenticata') : null))));
}
function renderJoin(){
  shell(false);
  const err = h('p',{class:'err',hidden:true});
  const name = h('input',{id:'j-name',autocomplete:'name',placeholder:'Nome e cognome',value:(S.user&&S.user.displayName)||''});
  const code = h('input',{id:'j-code',autocapitalize:'characters',placeholder:'Es. K7Q2MX',style:'text-transform:uppercase;letter-spacing:.1em'});
  const join = async e => {
    e.preventDefault(); err.hidden=true;
    const n=name.value.trim(), c=code.value.trim().toUpperCase();
    if (!n) { err.textContent='Scrivi il tuo nome.'; err.hidden=false; return; }
    if (!c) { err.textContent='Scrivi il codice che ti ha dato il docente.'; err.hidden=false; return; }
    try { await F.setDoc(D('members/'+S.uid), {name:n, code:c, joinedAt:Date.now()}); }
    catch (x) { err.textContent = (x.code||'').includes('permission') ? 'Codice classe errato. Controllalo con il docente.' : errMsg(x); err.hidden=false; }
  };
  const claim = async () => {
    const n=name.value.trim(); if (!n){ err.textContent='Scrivi il tuo nome.'; err.hidden=false; return; }
    try {
      await F.setDoc(D('config/teacher'), {uid:S.uid, since:Date.now()});
      await F.setDoc(D('secret/class'), {code:makeCode()});
      await F.setDoc(D('members/'+S.uid), {name:n, code:'', role:'docente', joinedAt:Date.now()});
    } catch (x) { err.textContent='Non è stato possibile: forse il docente è già registrato.'; err.hidden=false; }
  };
  $main.replaceChildren(h('div',{class:'auth'}, h('form',{class:'card',onsubmit:join},
    h('h1',{},'Entra nella classe'),
    h('label',{class:'f',for:'j-name'},'Il tuo nome (lo vedranno compagni e docente)',name),
    h('label',{class:'f',for:'j-code'},'Codice della classe',code), err,
    h('button',{class:'btn primary',type:'submit'},'Entra'),
    S.teacherUid===null ? h('div',{class:'notice'},
      h('p',{style:'margin:0 0 8px'},'Nessun docente è ancora registrato in questa app. Se sei il docente, tocca qui: diventerai l’unico amministratore della classe.'),
      h('button',{class:'btn ghost',type:'button',onclick:claim},'Sono il docente')) : null,
    h('button',{class:'linkbtn',type:'button',onclick:()=>F.signOut(S.fb.auth)},'Esci e usa un altro account'))));
}
function makeCode(){ const a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let s=''; const r=crypto.getRandomValues(new Uint32Array(6)); for (const x of r) s+=a[x%a.length]; return s; }

/* ================= calcoli ================= */
function scoresFor(subId){
  const vals=[]; let mine=null;
  for (const r of S.ratings) if (r.sub===subId && typeof r.stars==='number'){ vals.push(r.stars); if (r.rater===S.uid) mine=r.stars; }
  return {avg: vals.length ? vals.reduce((a,b)=>a+b,0)/vals.length : null, n:vals.length, mine};
}
const unseenTasks = () => S.owner ? 0 : S.tasks.filter(t=>(t.createdAt||0)>(S.state.seen||0)).length;
const nameOf = id => { const m=S.members.find(x=>x.id===id); return (m&&m.name) || (id===S.uid?'Tu':'Studente'); };

let chain = Promise.resolve();
const queue = fn => (chain = chain.then(fn, fn));
function saveState(patch){
  Object.assign(S.state, patch);
  return queue(()=>F.setDoc(D('users/'+S.uid+'/private/state'), {seen:S.state.seen||0, done:S.state.done||{}})).catch(()=>{});
}

/* ================= viste principali ================= */
function render(){
  if (!S.started) return;
  shell(true);
  document.getElementById('role').textContent = S.owner ? 'Docente' : 'Studente';
  const n = unseenTasks(); const b = document.getElementById('badge'); b.hidden=!n; b.textContent=n;
  document.querySelectorAll('nav.tabs button').forEach(x=>x.setAttribute('aria-selected', String(x.dataset.tab===S.tab)));
  const w = h('div',{class:'wrap'});
  ({lezioni:viewLessons, compiti:viewTasks, esercitazioni:viewSubs})[S.tab](w);
  const y = $main.scrollTop; $main.replaceChildren(w); $main.scrollTop = y;
}

function viewLessons(w){
  const L = S.lesson && S.lessons.find(l=>l.id===S.lesson);
  if (L) return viewLesson(w, L);
  w.append(h('div',{class:'sec-head'}, h('h2',{},'Lezioni'),
    S.owner ? h('button',{class:'btn primary small',onclick:()=>editLesson()},'+ Nuova lezione') : null));
  if (!S.loaded.lessons) return w.append(h('p',{class:'hint'},'Carico le lezioni…'));
  if (!S.lessons.length) return w.append(h('div',{class:'empty'}, S.owner ? 'Crea la prima lezione: sarà una cartella dove raccogliere i link a video, foto e audio.' : 'Il docente non ha ancora pubblicato lezioni.'));
  for (const l of S.lessons){
    const nl=(l.links||[]).length, nt=S.tasks.filter(t=>t.lessonId===l.id).length;
    w.append(h('button',{class:'card folder',onclick:()=>{S.lesson=l.id;render();$main.scrollTop=0;}},
      h('div',{class:'num'}, String(l.num ?? '')),
      h('div',{}, h('h3',{},l.title||'Senza titolo'), h('div',{class:'meta'}, nl+(nl===1?' materiale':' materiali')+(nt?' · '+nt+(nt===1?' compito':' compiti'):''))),
      h('span',{class:'chev','aria-hidden':'true'},'›')));
  }
}
function viewLesson(w, L){
  w.append(h('button',{class:'back',onclick:()=>{S.lesson=null;render();}},'‹ Tutte le lezioni'));
  w.append(h('div',{}, h('span',{class:'pill'},'Lezione '+(L.num??'')), h('h2',{style:'font-size:26px;margin-top:6px'},L.title||'Senza titolo')));
  if (L.desc) w.append(h('p',{style:'margin:0;white-space:pre-wrap'},L.desc));
  if (S.owner) w.append(h('div',{class:'row'},
    h('button',{class:'btn primary small',onclick:()=>editLink(L)},'+ Aggiungi link'),
    h('button',{class:'btn ghost small',onclick:()=>editLesson(L)},'Modifica'),
    h('button',{class:'btn danger small',onclick:()=>confirmBox('Eliminare la lezione?','La lezione "'+(L.title||'')+'" e i suoi link spariranno per tutti. I file su Mega o sugli altri cloud non vengono toccati.','Elimina',async()=>{ await F.deleteDoc(D('lessons/'+L.id)); S.lesson=null; render(); })},'Elimina')));
  const links = L.links||[];
  const card = h('div',{class:'card'});
  if (!links.length) card.append(h('p',{class:'hint'}, S.owner?'Nessun materiale. Incolla qui i link di Mega, Google Drive, Dropbox o YouTube.':'Nessun materiale per questa lezione.'));
  for (const k of links){
    const url = safeUrl(k.url);
    card.append(h('div',{class:'link'},
      h('div',{class:'kind',html:ICON[k.kind]||ICON.altro}),
      h('div',{}, h('div',{class:'t'},k.label||'Materiale'), h('div',{class:'d'}, (KINDS.find(x=>x[0]===k.kind)||[,'Link'])[1]+(url?' · '+host(url):''))),
      h('div',{class:'row'},
        url ? h('a',{class:'btn ghost small',href:url,target:'_blank',rel:'noopener noreferrer'},'Apri') : null,
        S.owner ? h('button',{class:'btn danger small','aria-label':'Rimuovi '+(k.label||'link'),onclick:()=>confirmBox('Rimuovere il link?','"'+(k.label||'')+'" non sarà più visibile agli studenti.','Rimuovi',()=>
          F.updateDoc(D('lessons/'+L.id), {links:(L.links||[]).filter(x=>x.id!==k.id)}))},'✕') : null)));
  }
  w.append(h('h3',{style:'font-size:18px;margin-top:6px'},'Materiali'), card);
  const tk = S.tasks.filter(t=>t.lessonId===L.id);
  if (tk.length){ w.append(h('h3',{style:'font-size:18px;margin-top:6px'},'Compiti di questa lezione')); tk.forEach(t=>w.append(taskCard(t))); }
}
function editLesson(L){
  const next = L ? L.num : (S.lessons.reduce((m,l)=>Math.max(m,Number(l.num)||0),0)+1);
  form(L?'Modifica lezione':'Nuova lezione',[
    {id:'num',label:'Numero',type:'number',inputmode:'numeric',value:next},
    {id:'title',label:'Titolo',value:L?L.title:'',placeholder:'Es. Scala di Do maggiore'},
    {id:'desc',label:'Descrizione (facoltativa)',type:'textarea',value:L?(L.desc||''):''}
  ], L?'Salva':'Crea lezione', async f=>{
    const title=f.title.value.trim(); if(!title) return 'Scrivi un titolo.';
    const body={num:Number(f.num.value)||next,title,desc:f.desc.value.trim()};
    if (L) await F.updateDoc(D('lessons/'+L.id), body);
    else { const id=newId(); S.lesson=id; await F.setDoc(D('lessons/'+id), {...body,links:[],createdAt:Date.now()}); render(); }
  });
}
function editLink(L){
  form('Aggiungi materiale',[
    {id:'label',label:'Nome',placeholder:'Es. Video esercizio 1'},
    {id:'url',label:'Link',type:'url',placeholder:'https://mega.nz/…',help:'Incolla il link di condivisione da Mega, Google Drive, Dropbox, YouTube…'},
    {id:'kind',label:'Tipo',type:'select',options:KINDS}
  ],'Aggiungi', async f=>{
    const url=safeUrl(f.url.value); if(!url) return 'Il link deve iniziare con https://';
    const item={id:newId(),label:f.label.value.trim()||host(url)||'Materiale',url,kind:f.kind.value};
    const cur=(S.lessons.find(x=>x.id===L.id)||L).links||[];
    await F.updateDoc(D('lessons/'+L.id), {links:[...cur,item]});
  });
}

function taskCard(t){
  const done = !!(S.state.done||{})[t.id];
  const isNew = !S.owner && (t.createdAt||0)>(S.state.seenBefore ?? S.state.seen ?? 0);
  const L = S.lessons.find(l=>l.id===t.lessonId);
  return h('div',{class:'card task'+(done&&!S.owner?' done':'')},
    S.owner ? h('div',{class:'kind',html:ICON.documento}) :
      h('button',{class:'check','aria-pressed':String(done),'aria-label':done?'Segna come da fare':'Segna come fatto',onclick:()=>{ const d={...(S.state.done||{})}; if(done) delete d[t.id]; else d[t.id]=true; saveState({done:d}); render(); Notif.reschedule(); }}, done?'✓':''),
    h('div',{style:'display:flex;flex-direction:column;gap:6px'},
      h('div',{class:'row'}, isNew?h('span',{class:'pill new'},'Nuovo'):null, dueChip(t.due), L?h('span',{class:'pill',style:'background:transparent;border:1px solid var(--line);color:var(--muted)'},'Lezione '+L.num):null),
      h('h3',{style:'font-size:17px'},t.title||'Compito'),
      t.due ? h('div',{class:'who'},'Da consegnare entro '+fmtDate(t.due)) : null,
      t.desc ? h('p',{style:'margin:0;white-space:pre-wrap'},t.desc) : null,
      S.owner ? h('div',{class:'row'}, h('button',{class:'btn danger small',onclick:()=>confirmBox('Eliminare il compito?','"'+(t.title||'')+'" sparirà dagli avvisi degli studenti.','Elimina',()=>F.deleteDoc(D('tasks/'+t.id)))},'Elimina')) : null));
}
function viewTasks(w){
  w.append(h('div',{class:'sec-head'}, h('h2',{},'Compiti'),
    S.owner ? h('button',{class:'btn primary small',onclick:newTask},'+ Nuovo compito') : null));
  w.append(h('p',{class:'hint'}, S.owner ? 'Gli studenti ricevono una notifica sul telefono e un promemoria il giorno prima della scadenza.' : 'Spunta i compiti che hai fatto: la spunta la vedi solo tu.'));
  if (!S.loaded.tasks) return w.append(h('p',{class:'hint'},'Carico i compiti…'));
  if (!S.tasks.length) return w.append(h('div',{class:'empty'},'Nessun compito per ora.'));
  const isDone = t => !!(S.state.done||{})[t.id];
  S.tasks.filter(t=>S.owner || !isDone(t)).forEach(t=>w.append(taskCard(t)));
  const done = S.owner ? [] : S.tasks.filter(isDone);
  if (done.length){ w.append(h('h3',{style:'font-size:16px;color:var(--muted);margin-top:8px'},'Fatti')); done.forEach(t=>w.append(taskCard(t))); }
}
function newTask(){
  form('Nuovo compito',[
    {id:'title',label:'Cosa devono fare',placeholder:'Es. Registrare l’esercizio 3 a 80 bpm'},
    {id:'due',label:'Scadenza',type:'date',value:todayStr()},
    {id:'lesson',label:'Lezione collegata',type:'select',options:[['','Nessuna'],...S.lessons.map(l=>[l.id,'Lezione '+l.num+' · '+l.title])]},
    {id:'desc',label:'Dettagli (facoltativi)',type:'textarea'}
  ],'Pubblica', async f=>{
    const title=f.title.value.trim(); if(!title) return 'Scrivi cosa devono fare.';
    await F.setDoc(D('tasks/'+newId()), {title,due:f.due.value||'',lessonId:f.lesson.value||'',desc:f.desc.value.trim(),createdAt:Date.now()});
    toast('Compito pubblicato');
  });
}

function starRow(s, mine){
  const set = async v => {
    const ref = D('ratings/'+s.id+'_'+S.uid);
    try {
      if (mine===v) await F.deleteDoc(ref);
      else await F.setDoc(ref, {sub:s.id, rater:S.uid, author:s.author, stars:v, at:Date.now()});
    } catch(e){ fail(e); }
  };
  const row = h('div',{class:'stars',role:'group','aria-label':'Il tuo voto da 0 a 10 stelle'});
  row.append(h('button',{class:'zero'+(mine===0?' on':''),'aria-label':'0 stelle',onclick:()=>set(0)},'0'));
  for (let i=1;i<=10;i++) row.append(h('button',{class:(mine!=null&&i<=mine)?'on':'','aria-label':i+(i===1?' stella':' stelle'),html:STAR,onclick:()=>set(i)}));
  return row;
}
function viewSubs(w){
  w.append(h('div',{class:'sec-head'}, h('h2',{},'Esercitazioni'), h('button',{class:'btn primary small',onclick:newSub},'+ Carica')));
  w.append(h('p',{class:'hint'},'Pubblica la tua esercitazione e dai un voto da 0 a 10 stelle a quelle dei compagni. Tocca di nuovo la stessa stella per togliere il voto.'));
  if (!S.loaded.subs) return w.append(h('p',{class:'hint'},'Carico le esercitazioni…'));
  if (!S.subs.length) return w.append(h('div',{class:'empty'},'Ancora nessuna esercitazione.'));
  for (const s of S.subs){
    const sc = scoresFor(s.id); const own = s.author===S.uid;
    const L = S.lessons.find(l=>l.id===s.lessonId);
    let media=null;
    if (s.fileUrl && s.kind==='video') media=h('video',{src:s.fileUrl,controls:true,playsinline:true,preload:'metadata'});
    else if (s.fileUrl && s.kind==='audio') media=h('audio',{src:s.fileUrl,controls:true,preload:'metadata'});
    else if (s.fileUrl && s.kind==='foto') media=h('img',{src:s.fileUrl,alt:s.title||'Foto esercitazione',loading:'lazy'});
    else if (safeUrl(s.url)) media=h('a',{class:'btn ghost',href:safeUrl(s.url),target:'_blank',rel:'noopener noreferrer'},'Apri su '+(host(s.url)||'link'));
    w.append(h('div',{class:'card sub'},
      h('div',{class:'row',style:'justify-content:space-between;align-items:flex-start'},
        h('div',{style:'flex:1;min-width:0'}, h('h3',{style:'font-size:17px'},s.title||'Esercitazione'), h('div',{class:'who'}, nameOf(s.author)+(L?' · Lezione '+L.num:'')+' · '+new Date(s.createdAt||0).toLocaleDateString('it-IT',{day:'numeric',month:'short'}))),
        h('div',{style:'text-align:right'}, h('div',{class:'score'}, sc.avg==null?'—':sc.avg.toFixed(1).replace('.',',')+' / 10'), h('div',{class:'who'}, sc.n+(sc.n===1?' voto':' voti')))),
      media,
      own ? h('div',{class:'row',style:'justify-content:space-between'}, h('span',{class:'who'},'È la tua esercitazione: non puoi votarla.'),
              h('button',{class:'btn danger small',onclick:()=>confirmBox('Eliminare la tua esercitazione?','"'+(s.title||'')+'" sparirà per tutti, insieme ai voti ricevuti.','Elimina',()=>removeSub(s))},'Elimina'))
          : h('div',{}, h('div',{class:'who'},sc.mine==null?'Il tuo voto':'Il tuo voto: '+sc.mine+' / 10'), starRow(s, sc.mine)),
      (S.owner && !own) ? h('button',{class:'btn danger small',style:'align-self:flex-start',onclick:()=>confirmBox('Rimuovere questa esercitazione?','Verrà tolta dalla bacheca della classe con i suoi voti.','Rimuovi',()=>removeSub(s))},'Rimuovi (docente)') : null));
  }
}
async function removeSub(s){
  const rs = await F.getDocs(F.query(C('ratings'), F.where('sub','==',s.id)));
  for (const r of rs.docs) await F.deleteDoc(r.ref);
  await F.deleteDoc(D('subs/'+s.id));
  if (s.filePath) { try { const st = await storage(); await st.deleteObject(st.ref(st.instance, s.filePath)); } catch {} }
}
let _st=null;
async function storage(){
  if (_st) return _st;
  const m = await import(FB+'firebase-storage.js');
  _st = {...m, instance:m.getStorage(S.fb.app)}; return _st;
}
function newSub(){
  const canUpload = !!(S.app && S.app.storage);
  const MAX = 200*1024*1024;
  form('Pubblica esercitazione',[
    {id:'title',label:'Titolo',placeholder:'Es. Esercizio 3 – seconda prova'},
    {id:'lesson',label:'Lezione',type:'select',options:[['','Nessuna'],...S.lessons.map(l=>[l.id,'Lezione '+l.num+' · '+l.title])]},
    ...(canUpload?[{id:'file',label:'Video, audio o foto dal telefono',type:'file',accept:'video/*,audio/*,image/*',help:'Fino a 200 MB.'}]:[]),
    {id:'url',label:canUpload?'Oppure un link (Mega, Drive, YouTube…)':'Link al tuo video o audio (Mega, Drive, YouTube…)',type:'url',placeholder:'https://…',
     help:canUpload?null:'Carica il file su Mega o Google Drive, condividilo con «chiunque abbia il link» e incollalo qui.'}
  ],'Pubblica', async f=>{
    const title=f.title.value.trim()||'Esercitazione';
    const file = f.file && f.file.files && f.file.files[0];
    const url = safeUrl(f.url.value);
    if (!file && !url) return canUpload ? 'Scegli un file oppure incolla un link che inizi con https://' : 'Incolla un link che inizi con https://';
    const id = newId();
    let data = {author:S.uid, title, lessonId:f.lesson.value||'', createdAt:Date.now()};
    if (file){
      if (file.size>MAX) return 'Il file supera 200 MB. Usa un link a Mega o Drive.';
      const t=file.type||''; const kind = t.startsWith('audio')?'audio':t.startsWith('image')?'foto':t.startsWith('video')?'video':null;
      if (!kind) return 'Puoi caricare solo video, audio o foto.';
      const st = await storage();
      const path = 'subs/'+S.uid+'/'+id+'-'+file.name.replace(/[^\w.\-]/g,'_').slice(-60);
      const bar = h('div'); f._err.before(h('div',{class:'progress'},bar));
      const task = st.uploadBytesResumable(st.ref(st.instance, path), file, {contentType:t});
      await new Promise((ok,ko)=>task.on('state_changed', s=>{ bar.style.width=Math.round(s.bytesTransferred/s.totalBytes*100)+'%'; }, ko, ok));
      data = {...data, kind, filePath:path, fileUrl: await st.getDownloadURL(task.snapshot.ref)};
    } else data = {...data, kind:'link', url};
    await F.setDoc(D('subs/'+id), data);
    toast('Esercitazione pubblicata');
  });
}

/* ================= impostazioni ================= */
function openSettings(){
  const me = S.members.find(m=>m.id===S.uid);
  const body = h('div',{style:'display:flex;flex-direction:column;gap:4px'});
  body.append(h('div',{class:'set-group',style:'border-top:0;padding-top:0'},
    h('div',{class:'who'},'Accesso come'), h('div',{style:'font-weight:700'}, (me&&me.name)||'', ' · ', (S.user&&S.user.email)||''),
    h('div',{class:'row'},
      h('button',{class:'btn ghost small',onclick:()=>{ document.querySelector('.sheet-bg')?.remove(); form('Il tuo nome',[{id:'n',label:'Nome visibile in classe',value:(me&&me.name)||''}],'Salva',async f=>{ const n=f.n.value.trim(); if(!n) return 'Scrivi un nome.'; await F.updateDoc(D('members/'+S.uid),{name:n}); }); }},'Cambia nome'),
      h('button',{class:'btn ghost small',onclick:()=>{ document.querySelector('.sheet-bg')?.remove(); Notif.cancelAll(); F.signOut(S.fb.auth); }},'Esci'))));
  body.append(h('div',{class:'set-group'}, h('h3',{},'Notifiche'), h('p',{class:'hint'}, Notif.available()
      ? (S.owner ? 'Le notifiche servono soprattutto agli studenti: nuovo compito e promemoria il giorno prima della scadenza.' : 'Ricevi una notifica per ogni nuovo compito e un promemoria il giorno prima della scadenza (ore 18) e la mattina stessa (ore 8).')
      : 'Le notifiche funzionano nell’app Android. Nella versione web controlla il numero rosso su «Compiti».'),
    Notif.available() ? h('button',{class:'btn ghost small',style:'align-self:flex-start',onclick:()=>Notif.ask(true)},'Attiva o verifica le notifiche') : null));
  if (S.owner){
    body.append(h('div',{class:'set-group'}, h('h3',{},'Codice della classe'),
      h('p',{class:'hint'},'Gli studenti lo inseriscono una volta, dopo essersi registrati.'),
      h('div',{class:'code'}, (S.secret&&S.secret.code)||'—'),
      h('button',{class:'btn ghost small',style:'align-self:flex-start',onclick:()=>confirmBox('Cambiare il codice?','Il vecchio codice smetterà di funzionare per i nuovi iscritti. Chi è già nella classe resta dentro.','Cambia',async()=>{ await F.setDoc(D('secret/class'),{code:makeCode()}); toast('Nuovo codice creato'); })},'Genera un nuovo codice')));
    const list = h('div',{});
    const studs = S.members.filter(m=>m.id!==S.uid).sort((a,b)=>(a.name||'').localeCompare(b.name||''));
    if (!studs.length) list.append(h('p',{class:'hint'},'Nessuno studente iscritto per ora.'));
    for (const m of studs) list.append(h('div',{class:'member'}, h('span',{},m.name||'Studente'),
      h('button',{class:'btn danger small',onclick:()=>confirmBox('Togliere '+(m.name||'lo studente')+' dalla classe?','Non potrà più vedere lezioni e compiti finché non rientra con il codice.','Togli',()=>F.deleteDoc(D('members/'+m.id)))},'Togli')));
    body.append(h('div',{class:'set-group'}, h('h3',{},'Studenti ('+studs.length+')'), list));
    body.append(h('div',{class:'set-group'}, h('h3',{},'Aspetto'), h('p',{class:'hint'},'Sfondo, sfumature e colori dell’app, uguali per tutta la classe.'),
      h('button',{class:'btn primary small',style:'align-self:flex-start',onclick:()=>{ document.querySelector('.sheet-bg')?.remove(); openCustomize(); }},'Personalizza')));
    const chk = h('input',{type:'checkbox',id:'st-on',checked:!!(S.app&&S.app.storage),style:'width:22px;height:22px;accent-color:var(--accent)',onchange:async e=>{
      try{ await F.setDoc(D('settings/app'),{storage:e.target.checked}); }catch(x){ e.target.checked=!e.target.checked; fail(x); } }});
    body.append(h('div',{class:'set-group'}, h('h3',{},'Caricamento diretto dei file'),
      h('p',{class:'hint'},'Attivalo solo dopo aver attivato il piano Blaze e Storage nel tuo progetto Firebase. Senza, gli studenti consegnano con un link.'),
      h('label',{class:'colors',for:'st-on',style:'font-weight:700;font-size:14px'}, chk, 'Permetti di caricare video, audio e foto')));
  }
  sheet('Impostazioni', body, close => h('div',{class:'row',style:'justify-content:flex-end'}, h('button',{class:'btn primary',type:'button',onclick:close},'Chiudi')));
}

/* ================= aspetto: sfondo e colori ================= */
const DEFAULT_THEME = {bgType:'none', bg1:'#C9E4DE', bg2:'#F7D9C4', angle:160, blur:0, veil:0,
  accent:'#1E5A47', shade:0, headerGrad:false, accent2:'#0E7C86', cardPct:100, cardBlur:0};
const PALETTE = [['#1E5A47','Ardesia'],['#0E7C86','Ottanio'],['#1F3F8F','Blu notte'],['#2F6FD6','Azzurro'],['#6B3FA0','Viola'],['#B0306A','Fucsia'],['#8E2741','Bordeaux'],['#C25A12','Arancio'],['#8A6D1F','Ocra'],['#3A4248','Grafite']];
const BG_PRESETS = [['#C9E4DE','#F7D9C4'],['#FDE68A','#F9A8D4'],['#BFDBFE','#DDD6FE'],['#A7F3D0','#0E7C86'],['#1F3F8F','#6B3FA0'],['#0F172A','#334155'],['#FECACA','#FDE68A'],['#E0E7FF','#F0FDFA']];
function hexToHsl(hex){
  const m = /^#?([0-9a-f]{6})$/i.exec(hex||''); if(!m) return [160,50,24];
  const n=parseInt(m[1],16); const r=(n>>16&255)/255,g=(n>>8&255)/255,b=(n&255)/255;
  const mx=Math.max(r,g,b), mn=Math.min(r,g,b); let hh=0,s=0; const l=(mx+mn)/2;
  if(mx!==mn){ const d=mx-mn; s=l>.5?d/(2-mx-mn):d/(mx+mn);
    hh = mx===r?((g-b)/d+(g<b?6:0)):mx===g?((b-r)/d+2):((r-g)/d+4); hh*=60; }
  return [Math.round(hh),Math.round(s*100),Math.round(l*100)];
}
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function isDark(){ try { return matchMedia('(prefers-color-scheme: dark)').matches; } catch { return false; } }
function shadeColor(hex, shade){
  const [hh,s,l]=hexToHsl(hex);
  let L = clamp(l+shade, 8, 85); if (isDark()) L = clamp(Math.max(L,58)+shade/2, 45, 88);
  return {css:`hsl(${hh} ${s}% ${L}%)`, L};
}
function applyTheme(t, bgData){
  t = {...DEFAULT_THEME, ...(t||{})}; const img = bgData!==undefined ? bgData : S.bgData;
  const root=document.documentElement.style, bg=document.getElementById('bg'), veil=document.getElementById('veil');
  const a = shadeColor(t.accent, Number(t.shade)||0), a2 = shadeColor(t.accent2, Number(t.shade)||0);
  root.setProperty('--accent', a.css);
  root.setProperty('--accent-ink', a.L>62 ? '#10140F' : '#FFFFFF');
  root.setProperty('--accent-soft', `color-mix(in srgb, ${a.css} ${isDark()?22:13}%, var(--surface))`);
  root.setProperty('--header-bg', t.headerGrad ? `linear-gradient(120deg, ${a.css}, ${a2.css})` : a.css);
  root.setProperty('--card-pct', (Number(t.cardPct)||100)+'%');
  root.setProperty('--card-blur', (Number(t.cardBlur)||0)+'px');
  bg.style.backgroundImage=''; bg.style.backgroundColor='';
  if (t.bgType==='color') bg.style.backgroundColor=t.bg1;
  else if (t.bgType==='gradient') bg.style.backgroundImage=`linear-gradient(${Number(t.angle)||0}deg, ${t.bg1}, ${t.bg2})`;
  else if (t.bgType==='image' && img && img.startsWith('data:image/')) bg.style.backgroundImage=`url("${img}")`;
  bg.style.filter = (Number(t.blur)||0) ? `blur(${Number(t.blur)}px)` : '';
  veil.style.opacity = String((Number(t.veil)||0)/100);
  document.body.classList.toggle('has-bg', t.bgType!=='none');
  const meta = document.querySelector('meta[name="theme-color"]'); if (meta) meta.content = a.css;
}
try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>applyTheme(S.theme)); } catch {}

async function shrinkImage(file){
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((ok,ko)=>{ const i=new Image(); i.onload=()=>ok(i); i.onerror=ko; i.src=url; });
    let max=1400, q=.78, out='';
    for (let k=0;k<8;k++){
      const sc=Math.min(1, max/Math.max(img.width,img.height));
      const c=document.createElement('canvas'); c.width=Math.round(img.width*sc); c.height=Math.round(img.height*sc);
      c.getContext('2d').drawImage(img,0,0,c.width,c.height);
      out=c.toDataURL('image/jpeg',q);
      if (out.length < 700000) return out;
      max*=.82; q=Math.max(.5,q-.06);
    }
    return out.length < 950000 ? out : null;
  } finally { URL.revokeObjectURL(url); }
}
function openCustomize(){
  const saved = {...DEFAULT_THEME, ...(S.theme||{})}, savedImg = S.bgData;
  let t = {...saved}, img = savedImg, done=false; S.customizing=true;
  const live = () => applyTheme(t, img);
  const body = h('div',{});
  const draw = () => {
    const rng = (key,label,min,max,step,unit) => {
      const out = h('output',{}, t[key]+unit);
      return h('label',{class:'rng'}, label, out, h('input',{type:'range',min,max,step,value:t[key],oninput:e=>{ t[key]=Number(e.target.value); out.textContent=t[key]+unit; live(); }}));
    };
    const col = (key,label) => h('label',{}, label, h('input',{type:'color',value:t[key],oninput:e=>{ t[key]=e.target.value; live(); }}));
    const seg = h('div',{class:'seg',role:'group','aria-label':'Tipo di sfondo'},
      [['none','Nessuno'],['color','Colore'],['gradient','Sfumato'],['image','Foto']].map(([v,l])=>
        h('button',{type:'button','aria-pressed':String(t.bgType===v),onclick:()=>{ t.bgType=v; if(v==='image'&&!t.veil) t.veil=30; if(v!=='none'&&t.cardPct===100) t.cardPct=88; live(); draw(); }},l)));
    const box = h('div',{style:'display:flex;flex-direction:column;gap:10px'});
    if (t.bgType==='color') box.append(h('div',{class:'colors'}, col('bg1','Colore')),
      h('div',{class:'swatches'}, [...new Set(BG_PRESETS.flat())].slice(0,10).map(c=>h('button',{type:'button',class:'sw','aria-label':'Colore '+c,'aria-pressed':String(t.bg1===c),style:'background:'+c,onclick:()=>{t.bg1=c;live();draw();}}))));
    if (t.bgType==='gradient') box.append(
      h('div',{class:'swatches'}, BG_PRESETS.map(([c1,c2],i)=>h('button',{type:'button',class:'sw','aria-label':'Sfumatura '+(i+1),'aria-pressed':String(t.bg1===c1&&t.bg2===c2),style:`background:linear-gradient(135deg,${c1},${c2})`,onclick:()=>{t.bg1=c1;t.bg2=c2;live();draw();}}))),
      h('div',{class:'colors'}, col('bg1','Da'), col('bg2','A')),
      rng('angle','Direzione della sfumatura',0,360,5,'°'));
    if (t.bgType==='image'){
      const msg = h('p',{class:'hint'}, img ? 'Foto scelta. Puoi sceglierne un’altra.' : 'Scegli una foto dal telefono.');
      box.append(h('label',{class:'f',for:'bg-file'},'Foto di sfondo', h('input',{type:'file',accept:'image/*',id:'bg-file',onchange:async e=>{
        const f=e.target.files[0]; if(!f) return; msg.textContent='Preparo la foto…';
        try{ const d=await shrinkImage(f); if(!d){ msg.textContent='La foto è troppo pesante: scegline un’altra.'; return; } img=d; live(); msg.textContent='Foto pronta. Regola sfocatura e velo qui sotto.'; }
        catch{ msg.textContent='Non riesco ad aprire questa foto. Prova con un’altra.'; }
      }})), msg);
    }
    if (t.bgType!=='none') box.append(
      rng('blur','Sfocatura dello sfondo',0,30,1,' px'),
      rng('veil','Velo (rende lo sfondo più opaco)',0,90,5,'%'),
      rng('cardPct','Opacità delle schede',30,100,5,'%'),
      rng('cardBlur','Effetto vetro delle schede',0,20,1,' px'));
    const acc = h('div',{style:'display:flex;flex-direction:column;gap:10px'},
      h('div',{class:'swatches'}, PALETTE.map(([c,n])=>h('button',{type:'button',class:'sw','aria-label':n,title:n,'aria-pressed':String(t.accent.toLowerCase()===c.toLowerCase()),style:'background:'+c,onclick:()=>{t.accent=c;live();draw();}}))),
      h('div',{class:'colors'}, col('accent','Colore personalizzato')),
      rng('shade','Gradazione (più scuro ← → più chiaro)',-25,25,1,''),
      h('label',{class:'colors',style:'font-weight:700;font-size:14px'}, h('input',{type:'checkbox',checked:t.headerGrad,style:'width:22px;height:22px;accent-color:var(--accent)',onchange:e=>{t.headerGrad=e.target.checked;live();draw();}}),'Intestazione sfumata'),
      t.headerGrad ? h('div',{class:'colors'}, col('accent2','Secondo colore'),
        h('div',{class:'swatches'}, PALETTE.slice(0,6).map(([c,n])=>h('button',{type:'button',class:'sw',style:'width:32px;height:32px;background:'+c,'aria-label':'Sfuma verso '+n,'aria-pressed':String(t.accent2===c),onclick:()=>{t.accent2=c;live();draw();}})))) : null);
    body.replaceChildren(
      h('p',{class:'hint',style:'margin:0'},'Le modifiche si vedono subito qui dietro. Con «Salva» valgono per tutta la classe.'),
      h('div',{class:'set-group'}, h('h3',{},'Sfondo'), seg, box),
      h('div',{class:'set-group'}, h('h3',{},'Colore dell’app'), acc));
  };
  draw();
  const end = () => { S.customizing=false; };
  const bg = sheet('Personalizza', body, close => h('div',{class:'row',style:'justify-content:space-between'},
    h('button',{class:'btn ghost small',type:'button',onclick:()=>{ t={...DEFAULT_THEME}; live(); draw(); }},'Ripristina'),
    h('div',{class:'row'},
      h('button',{class:'btn ghost',type:'button',onclick:()=>{ applyTheme(saved, savedImg); end(); close(); }},'Annulla'),
      h('button',{class:'btn primary',type:'button',onclick:async()=>{
        done=true; close();
        try{
          await F.setDoc(D('settings/theme'), t);
          if (img!==savedImg) await F.setDoc(D('settings/background'), {data: img||''});
          S.theme={...t}; S.bgData=img; toast('Aspetto salvato per tutta la classe');
        } catch(e){ applyTheme(saved, savedImg); fail(e); }
        end();
      }},'Salva'))));
  bg.style.background='rgba(0,0,0,.15)';
  bg.addEventListener('click', e=>{ if(e.target===bg && !done){ applyTheme(saved, savedImg); end(); } });
}

/* ================= notifiche (app Android) ================= */
const Notif = {
  LN(){ const C=window.Capacitor; return C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.LocalNotifications; },
  available(){ return !!this.LN(); },
  id(str){ let x=0; for (const ch of str) x=(x*31+ch.charCodeAt(0))|0; return (Math.abs(x)%2000000000)+1; },
  async ask(verbose){
    const LN=this.LN(); if(!LN) return false;
    try {
      let p = await LN.checkPermissions();
      if (p.display!=='granted') p = await LN.requestPermissions();
      const ok = p.display==='granted';
      if (verbose) toast(ok ? 'Notifiche attive' : 'Notifiche bloccate: attivale nelle impostazioni del telefono per Aula Digitale.');
      if (ok) this.reschedule();
      return ok;
    } catch { return false; }
  },
  init(){ if (this.LN()) this.ask(false); },
  async cancelAll(){
    const LN=this.LN(); if(!LN) return;
    try { const p = await LN.getPending(); if (p.notifications.length) await LN.cancel({notifications:p.notifications.map(n=>({id:n.id}))}); } catch {}
  },
  _t:null,
  reschedule(){ clearTimeout(this._t); this._t=setTimeout(()=>this._do(), 800); },
  async _do(){
    const LN=this.LN(); if(!LN || S.owner || !S.loaded.tasks || !S.loaded.state) return;
    try {
      const notes=[]; const now=Date.now();
      // nuovi compiti mai notificati
      const told = new Set(ls.get('notified',[]));
      for (const t of S.tasks){
        if ((t.createdAt||0) > (S.state.seen||0) && now-(t.createdAt||0) < 3*86400000 && !told.has(t.id) && !(S.state.done||{})[t.id]){
          notes.push({id:this.id('new'+t.id), title:'Nuovo compito', body:t.title + (t.due?' · entro '+fmtDate(t.due):''), schedule:{at:new Date(now+1500)}});
          told.add(t.id);
        }
      }
      ls.set('notified',[...told].slice(-300));
      // promemoria scadenze
      const old = ls.get('reminders',[]);
      if (old.length) { try { await LN.cancel({notifications:old.map(id=>({id}))}); } catch {} }
      const rem=[];
      for (const t of S.tasks){
        if ((S.state.done||{})[t.id] || !t.due) continue;
        const d=parseDue(t.due);
        const eve=new Date(d); eve.setDate(eve.getDate()-1); eve.setHours(18,0,0,0);
        const morn=new Date(d); morn.setHours(8,0,0,0);
        if (eve.getTime()>now) rem.push({id:this.id('eve'+t.id), title:'Domani scade un compito', body:t.title, schedule:{at:eve, allowWhileIdle:true}});
        if (morn.getTime()>now) rem.push({id:this.id('day'+t.id), title:'Oggi scade un compito', body:t.title, schedule:{at:morn, allowWhileIdle:true}});
      }
      rem.sort((a,b)=>a.schedule.at-b.schedule.at); const keep=rem.slice(0,40);
      ls.set('reminders', keep.map(n=>n.id));
      const all=[...notes,...keep];
      if (all.length) await LN.schedule({notifications:all});
    } catch (e) { console.warn('notifiche', e); }
  }
};
function onData(name){ if (name==='tasks' || name==='state') Notif.reschedule(); }

/* ================= navigazione ================= */
document.querySelectorAll('nav.tabs button').forEach(b=>b.addEventListener('click',()=>{
  S.tab=b.dataset.tab; if (S.tab!=='lezioni') S.lesson=null;
  if (S.tab==='compiti' && !S.owner && S.loaded.tasks){
    S.state.seenBefore = S.state.seen||0;
    const latest = S.tasks.reduce((m,t)=>Math.max(m,t.createdAt||0),0);
    if (latest > (S.state.seen||0)) saveState({seen:latest});
  } else delete S.state.seenBefore;
  render(); $main.scrollTop=0;
}));
document.getElementById('gear').addEventListener('click', ()=>{ if (S.started) openSettings(); });

// tasto Indietro di Android
(function(){
  const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if (!App) return;
  App.addListener('backButton', ()=>{
    const open = document.querySelector('.sheet-bg');
    if (open){ open.remove(); if (S.customizing){ applyTheme(S.theme); S.customizing=false; } return; }
    if (S.lesson){ S.lesson=null; render(); return; }
    if (S.started && S.tab!=='lezioni'){ S.tab='lezioni'; render(); return; }
    App.exitApp();
  });
  App.addListener('resume', ()=>Notif.reschedule());
})();

applyTheme(null);
boot();
