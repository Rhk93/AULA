// Viene sostituito automaticamente durante la compilazione con il contenuto
// del file firebase-config.txt che incolli su GitHub.
window.FIREBASE_CONFIG = { apiKey: "INCOLLA-QUI" };
